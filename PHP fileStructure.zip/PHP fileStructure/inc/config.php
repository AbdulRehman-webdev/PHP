<?php 
$SERVER = "localhost";
$USERNAME = "root";
$PASSWORD = "";
$DBNAME = "booking";
$conn = mysqli_connect($SERVER, $USERNAME, $PASSWORD, $DBNAME);
?>
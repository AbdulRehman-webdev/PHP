<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin&display=swap" rel="stylesheet">

<style type="text/css">
	body {
		font-family: 'Libre Franklin', sans-serif !important;
		font-size: 12.50px;
	}
</style>
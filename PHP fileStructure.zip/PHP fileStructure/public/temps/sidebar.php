<aside class="main-sidebar sidebar-light-warning elevation-4">
    <a href="index" class="brand-link"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fas fa-fw fa-user-shield"></i> <span class="brand-text font-weight-light">fast-EX</span> </a>
    <div class="sidebar">
        <nav class="mt-2 nav-flat">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item has-treeview menu-open">
                    <a href="index" class="nav-link active">
                        <i class="fa fa-home nav-icon" aria-hidden="true"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="shipments" class="nav-link">
                        <i class="fas fa-fw fa-box-open nav-icon"></i>
                        <p>
                            Shipments&nbsp;<span class="badge badge-dark badge-btn"></span>
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="reports" class="nav-link">
                        <i class="fas fa-fw fa-chart-area nav-icon"></i>
                        <p>
                            Reports&nbsp;<span class="badge badge-dark badge-btn"></span>
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="pricing-rules" class="nav-link">
                        <i class="fas fa-fw fa-hand-sparkles nav-icon"></i>
                        <p>
                            Pricing rules&nbsp;<span class="badge badge-dark badge-btn"></span>
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="destinations" class="nav-link">
                        <i class="fas fa-fw fa-building nav-icon"></i>
                        <p>
                            Destinations&nbsp;<span class="badge badge-dark badge-btn"></span>
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="customers" class="nav-link">
                        <i class="fas fa-fw fa-user-friends nav-icon"></i>
                        <p>
                            Customers&nbsp;<span class="badge badge-dark badge-btn"></span>
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="franchises" class="nav-link">
                        <i class="fas fa-fw fa-users nav-icon"></i>
                        <p>
                            Franchises&nbsp;<span class="badge badge-dark badge-btn"></span>
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="warehouses" class="nav-link">
                        <i class="fas fa-fw fa-warehouse nav-icon"></i>
                        <p>
                            Warehouses&nbsp;<span class="badge badge-dark badge-btn"></span>
                        </p>
                    </a>
                </li>
               <li class="nav-item">
                    <a href="shippers" class="nav-link">
                        <i class="fas fa-fw fa-people-carry nav-icon"></i>
                        <p>
                            Shippers&nbsp;<span class="badge badge-dark badge-btn"></span>
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="notifications" class="nav-link">
                        <i class="fas fa-fw fa-bell nav-icon"></i>
                        <p>
                            Notifications&nbsp;<span class="badge badge-dark badge-btn"></span>
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link" data-toggle="modal" data-target="#logout">
                        <i class="fa fa-power-off nav-icon"></i>
                        <p>Logout</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>
<div class="modal fade" id="logout" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Logout confirmation</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to Logout?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <form method="POST" action="logout">
                    <input type="submit" name="logout" id="logout" class="btn btn-warning" value="Logout" />
                </form>
            </div>
        </div>
    </div>
</div>

<footer class="main-footer">
   <strong>
   fast-EX
   <i class="fas fa-copyright"></i>
   <?php echo date("Y"); ?>
   <a href="#" target="_blank">
   </a>
   All rights reserved.
   </strong>
   <div class="float-right d-none d-sm-inline-block">
   <b> <a href="#">Version 1.0.1</b></a>
</footer>
<?php

function dateFormat($date)
{
    return date('l, F j, Y',strtotime($date));
}

function CreatedCDate() {
	date_default_timezone_set("Asia/Karachi");
	return date("F j, Y h:i:s A");
}

function CreatedDate() {
	date_default_timezone_set("Asia/Karachi");
	return date("Y-m-d");
}

function CreatedTime() {
	date_default_timezone_set("Asia/Karachi");
	return date("h:i:s A");
}

function CreatedDay() {
	date_default_timezone_set("Asia/Karachi");
	return date("l");
}

function CreatedBy() {
	return $_SESSION['email'];
}

function UpdatedCDate() {
	date_default_timezone_set("Asia/Karachi");
	return date("F j, Y h:i:s A");
}

function UpdatedDate() {
	date_default_timezone_set("Asia/Karachi");
	return date("Y-m-d");
}

function UpdatedTime() {
	date_default_timezone_set("Asia/Karachi");
	return date("h:i:s A");
}

function UpdatedDay() {
	date_default_timezone_set("Asia/Karachi");
	return date("l");
}

function UpdatedBy() {
	return $_SESSION['email'];
}

function emailDate()
{
    date_default_timezone_set("Asia/Karachi");
    return date("F j, Y");
}

// uploads

function uploadYear()
{
    date_default_timezone_set("Asia/Karachi");
    return date("Y");
}

function uploadMonth()
{
    date_default_timezone_set("Asia/Karachi");
    return date("m");
}

function uploadDay()
{
    date_default_timezone_set("Asia/Karachi");
    return date("d");
}

?>